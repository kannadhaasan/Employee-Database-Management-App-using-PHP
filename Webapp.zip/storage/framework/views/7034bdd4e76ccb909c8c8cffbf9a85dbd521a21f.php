<?php $__env->startSection('content'); ?>
  <div class="card">
      <div class="card-content">
      <span class="card-title"> <?php echo e($survey->title); ?></span>
      <p>
        <?php echo e($survey->description); ?>

      </p>
      <br/>
      <a href='view/<?php echo e($survey->id); ?>'>Take Survey</a> | <a href="<?php echo e($survey->id); ?>/edit">Edit Survey</a> | <a href="/survey/answers/<?php echo e($survey->id); ?>">View Answers</a> <a href="#doDelete" style="float:right;" class="modal-trigger red-text">Delete Survey</a>
      <!-- Modal Structure -->
      <!-- TODO Fix the Delete aspect -->
      <div id="doDelete" class="modal bottom-sheet">
        <div class="modal-content">
          <div class="container">
            <div class="row">
              <h4>Are you sure?</h4>
              <p>Do you wish to delete this survey called "<?php echo e($survey->title); ?>"?</p>
              <div class="modal-footer">
                <a href="/survey/<?php echo e($survey->id); ?>/delete" class=" modal-action waves-effect waves-light btn-flat red-text">Yep yep!</a>
                <a class=" modal-action modal-close waves-effect waves-light green white-text btn">No, stop!</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="divider" style="margin:20px 0px;"></div>
      <p class="flow-text center-align">Questions</p>
      <ul class="collapsible" data-collapsible="expandable">
          <?php $__empty_1 = true; foreach($survey->questions as $question): $__empty_1 = false; ?>
          <li style="box-shadow:none;">
            <div class="collapsible-header"><?php echo e($question->title); ?> <a href="/question/<?php echo e($question->id); ?>/edit" style="float:right;">Edit</a></div>
            <div class="collapsible-body">
              <div style="margin:5px; padding:10px;">
                  <?php echo Form::open(); ?>

                    <?php if($question->question_type === 'text'): ?>
                      <?php echo e(Form::text('title')); ?>

                    <?php elseif($question->question_type === 'textarea'): ?>
                    <div class="row">
                      <div class="input-field col s12">
                        <textarea id="textarea1" class="materialize-textarea"></textarea>
                        <label for="textarea1">Provide answer</label>
                      </div>
                    </div>
                    <?php elseif($question->question_type === 'radio'): ?>
                      <?php foreach($question->option_name as $key=>$value): ?>
                        <p style="margin:0px; padding:0px;">
                          <input type="radio" id="<?php echo e($key); ?>" />
                          <label for="<?php echo e($key); ?>"><?php echo e($value); ?></label>
                        </p>
                      <?php endforeach; ?>
                    <?php elseif($question->question_type === 'checkbox'): ?>
                      <?php foreach($question->option_name as $key=>$value): ?>
                      <p style="margin:0px; padding:0px;">
                        <input type="checkbox" id="<?php echo e($key); ?>" />
                        <label for="<?php echo e($key); ?>"><?php echo e($value); ?></label>
                      </p>
                      <?php endforeach; ?>
                    <?php endif; ?> 
                  <?php echo Form::close(); ?>

              </div>
            </div>
          </li>
          <?php endforeach; if ($__empty_1): ?>
            <span style="padding:10px;">Nothing to show. Add questions below.</span>
          <?php endif; ?>
      </ul>
      <h2 class="flow-text">Add Question</h2>
      <form method="POST" action="<?php echo e($survey->id); ?>/questions" id="boolean">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="row">
          <div class="input-field col s12">
            <select class="browser-default" name="question_type" id="question_type">
              <option value="" disabled selected>Choose your option</option>
              <option value="text">Text</option>
              <option value="textarea">Textarea</option>
              <option value="checkbox">Checkbox</option>
              <option value="radio">Radio Buttons</option>
            </select>
          </div>                
          <div class="input-field col s12">
            <input name="title" id="title" type="text">
            <label for="title">Question</label>
          </div>  
          <!-- this part will be chewed by script in init.js -->
          <span class="form-g"></span>

          <div class="input-field col s12">
          <button class="btn waves-effect waves-light">Submit</button>
          </div>
        </div>
        </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>