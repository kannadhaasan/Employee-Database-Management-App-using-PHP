<?php $__env->startSection('content'); ?>
<form method="POST" action="/question/<?php echo e($question->id); ?>/update">
  <?php echo e(method_field('PATCH')); ?>

  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
  <h2 class="flow-text">Edit Question Title</h2>
   <div class="row">
    <div class="input-field col s12">
      <input type="text" name="title" id="title" value="<?php echo e($question->title); ?>">
      <label for="title">Question</label>
    </div>
    <div class="input-field col s12">
    <button class="btn waves-effect waves-light">Update</button>
    </div>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>