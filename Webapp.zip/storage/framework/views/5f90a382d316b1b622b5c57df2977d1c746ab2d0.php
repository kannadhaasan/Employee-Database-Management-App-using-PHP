<?php $__env->startSection('content'); ?>
<ul class="collection with-header">
    <li class="collection-header">
        <h2 class="flow-text">Recent Surveys
            <span style="float:right;"><?php echo e(link_to_route('new.survey', 'Create new')); ?>

            </span>
        </h2>
    </li>

    <?php $__empty_1 = true; foreach($surveys as $survey): $__empty_1 = false; ?>
      <li class="collection-item">
        <div>
            <?php echo e(link_to_route('detail.survey', $survey->title, ['id'=>$survey->id])); ?>

            <a href="survey/view/<?php echo e($survey->id); ?>" title="Take Survey" class="secondary-content"><i class="material-icons">send</i></a>
            <a href="survey/<?php echo e($survey->id); ?>" title="Edit Survey" class="secondary-content"><i class="material-icons">edit</i></a>
            <a href="survey/answers/<?php echo e($survey->id); ?>" title="View Survey Answers" class="secondary-content"><i class="material-icons">textsms</i></a>
        </div>
        </li>
    <?php endforeach; if ($__empty_1): ?>
        <p class="flow-text center-align">Nothing to show</p>
    <?php endif; ?>
    </ul>
    <?php $__empty_1 = true; foreach($surveys as $survey): $__empty_1 = false; ?>
  <li class="collection-item">
    <div><a href="survey/<?php echo e($survey->id); ?>"><?php echo e($survey->title); ?></a>
        <a href="survey/view/<?php echo e($survey->id); ?>" title="Take Survey" class="secondary-content"><i class="material-icons">send</i></a>
        <a href="survey/<?php echo e($survey->id); ?>" title="Edit Survey" class="secondary-content"><i class="material-icons">edit</i></a>
        <a href="survey/answers/<?php echo e($survey->id); ?>" title="View Survey Answers" class="secondary-content"><i class="material-icons">textsms</i></a>
    </div>
    </li>
<?php endforeach; if ($__empty_1): ?>
    <p class="flow-text center-align">Nothing to show</p>
<?php endif; ?>
</ul>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>