<!DOCTYPE html>
<html>
    <head>
        <title>ABC limited</title>
        <?php echo MaterializeCSS::include_css(); ?>

        <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="/css/custom.css" rel="stylesheet">
    </head>

    <body>
      <div class="container">
          <div class="row" style="padding-top:10px;">
              <div class="center-align">
                <a class="btn blue waves-effect waves-light lighten-1 white-text" href="/"> Home </a>
                  <?php if(Auth::check()): ?>
                    <a class="btn-flat waves-effect waves-light darken-1 white black-text" href="/logout"> Logout </a>
                    <a class="btn-flat disabled" href="#" style="text-transform:none;"><?php echo e(Auth::user()->email); ?></a>
                  <?php else: ?>
                    <a class="btn-flat waves-effect waves-light darken-1 white black-text" href="/login"> Login </a>
                    <a class="btn-flat waves-effect waves-light darken-1 white black-text" href="/register"> Register </a>
                  <?php endif; ?>
              </div>
          </div>
          <div class="row">
              <div class="col s12 m10 offset-m1 l8 offset-l2" style="margin-top:10px;">
                <?php echo $__env->yieldContent('content'); ?>
              </div>
          </div>
      </div>
    </body>
    <script src="<?php echo e(URL::asset('jquery.min.js')); ?>"></script>
    <?php echo MaterializeCSS::include_js(); ?>

    <script src="<?php echo e(URL::asset('init.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</html>
