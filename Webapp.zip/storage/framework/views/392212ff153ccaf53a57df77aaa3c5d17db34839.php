<?php $__env->startSection('content'); ?>
<h4><?php echo e($survey->title); ?></h4>
<table class="bordered striped">
  <thead>
    <tr>
        <th data-field="id">Question</th>
        <th data-field="name">Answer(s)</th>
    </tr>
  </thead>

  <tbody>
    <?php $__empty_1 = true; foreach($survey->questions as $item): $__empty_1 = false; ?>
    <tr>
      <td><?php echo e($item->title); ?></td>
      <?php foreach($item->answers as $answer): ?>
        <td><?php echo e($answer->answer); ?> <br/>
        <small><?php echo e($answer->created_at); ?></small></td>
      <?php endforeach; ?>
    </tr>
    <?php endforeach; if ($__empty_1): ?>
      <tr>
        <td>
          No answers provided by you for this Survey
        </td>
        <td></td>
      </tr>
    <?php endif; ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>