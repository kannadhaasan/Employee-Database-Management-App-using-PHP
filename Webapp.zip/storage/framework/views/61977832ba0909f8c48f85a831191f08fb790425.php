<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col s12 m10 l8 offset-m1 offset-l2">
            <div class="flow-text">Login</div>
            <div class="divider"></div>
            <form role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="input-field col s12 <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                  <input id="email" type="email" class="validate" name="email" value="<?php echo e(old('email')); ?>" required>
                  <label for="email">E-mail Address</label>
                    <?php if($errors->has('email')): ?>
                        <div class="col s12">
                            <span class="red-text">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="input-field col s12 <?php echo e($errors->has('password') ? ' has-error' : ''); ?>" required>
                    <input type="password" name="password" class="validate" min="8" id="password">
                    <label for="password">Password</label>
                    <?php if($errors->has('password')): ?>
                        <span class="red-text">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <p class="col s12">
                  <input type="checkbox" id="remember" name="remember" />
                  <label for="remember">Remember Me</label>
                </p>

                <div class="input-field col s12">
                    <button type="submit" class="btn waves-effect waves-light">Login</button>
                    <p>
                        <a class="" href="<?php echo e(url('/password/reset')); ?>">Forgot Your Password?</a>
                    </p>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>