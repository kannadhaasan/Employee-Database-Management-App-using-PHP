<?php $__env->startSection('content'); ?>
  <div class="card">
      <div class="card-content">
      <span class="card-title"> Start taking Survey</span>
      <p>
        <span class="flow-text"><?php echo e($survey->title); ?></span> <br/>
      </p>
      <p>  
        <?php echo e($survey->description); ?>

        <br/>Created by: <a href=""><?php echo e($survey->user->name); ?></a>
      </p>
      <div class="divider" style="margin:20px 0px;"></div>
          <?php echo Form::open(array('action'=>array('AnswerController@store', $survey->id))); ?>

          <?php $__empty_1 = true; foreach($survey->questions as $key=>$question): $__empty_1 = false; ?>
            <p class="flow-text">Question <?php echo e($key+1); ?> - <?php echo e($question->title); ?></p>
                <?php if($question->question_type === 'text'): ?>
                  <div class="input-field col s12">
                    <input id="answer" type="text" name="<?php echo e($question->id); ?>[answer]">
                    <label for="answer">Answer</label>
                  </div>
                <?php elseif($question->question_type === 'textarea'): ?>
                  <div class="input-field col s12">
                    <textarea id="textarea1" class="materialize-textarea" name="<?php echo e($question->id); ?>[answer]"></textarea>
                    <label for="textarea1">Textarea</label>
                  </div>
                <?php elseif($question->question_type === 'radio'): ?>
                  <?php foreach($question->option_name as $key=>$value): ?>
                    <p style="margin:0px; padding:0px;">
                      <input name="<?php echo e($question->id); ?>[answer]" type="radio" id="<?php echo e($key); ?>" />
                      <label for="<?php echo e($key); ?>"><?php echo e($value); ?></label>
                    </p>
                  <?php endforeach; ?>
                <?php elseif($question->question_type === 'checkbox'): ?>
                  <?php foreach($question->option_name as $key=>$value): ?>
                  <p style="margin:0px; padding:0px;">
                    <input type="checkbox" id="something<?php echo e($key); ?>" name="<?php echo e($question->id); ?>[answer]" />
                    <label for="something<?php echo e($key); ?>"><?php echo e($value); ?></label>
                  </p>
                  <?php endforeach; ?>
                <?php endif; ?> 
              <div class="divider" style="margin:10px 10px;"></div>
          <?php endforeach; if ($__empty_1): ?>
            <span class='flow-text center-align'>Nothing to show</span>
          <?php endif; ?>
        <?php echo e(Form::submit('Submit Survey', array('class'=>'btn waves-effect waves-light'))); ?>

        <?php echo Form::close(); ?>

    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>