<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col s12 m10 l8 offset-m1 offset-l2">
        <span class="flow-text">Register</span>
        <div class="divider"></div>
        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="input-field col s12<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                  <input id="name" type="text" class="validate" name="name" value="<?php echo e(old('name')); ?>" required>
                  <label for="name">Name</label>
                    <?php if($errors->has('name')): ?>
                        <span class="red-text">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="input-field col s12<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                  <input id="email" type="email" class="validate" name="email" value="<?php echo e(old('email')); ?>" required>
                  <label for="email">E-mail Address</label>
                    <?php if($errors->has('email')): ?>
                        <div class="col s12">
                            <span class="red-text">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="input-field col s12<?php echo e($errors->has('password') ? ' has-error' : ''); ?>" required>
                    <input type="password" name="password" class="validate" min="8" id="password">
                    <label for="password">Password</label>
                    <?php if($errors->has('password')): ?>
                        <span class="red-text">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="input-field col s12<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                    <input id="password-confirm" type="password" class="validate" name="password_confirmation">
                    <label>Confirm Password</label>
                    <?php if($errors->has('password_confirmation')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                    <div class="input-field col s12">
                        <button type="submit" class="btn waves-effect waves-light">Register</button>
                        <p>
                            <a class="" href="<?php echo e(url('/login')); ?>">Have an account?</a>
                        </p>
                    </div>
                </form>
            </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>