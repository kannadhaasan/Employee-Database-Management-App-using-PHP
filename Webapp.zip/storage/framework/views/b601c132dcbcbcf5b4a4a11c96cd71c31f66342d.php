<?php $__env->startSection('content'); ?>
  <div class="card">
      <div class="card-content">
      <span class="card-title"> Start taking Survey</span>
      <p>
        <span class="flow-text"><?php echo e($survey->title); ?></span> <br/>
      </p>
      <p>  
        <?php echo e($survey->description); ?>

        <br/>Created by: <a href=""><?php echo e($survey->user->name); ?></a>
      </p>
      <div class="divider" style="margin:20px 0px;"></div>
          <?php echo Form::open(array('action'=>array('AnswerController@store', $survey->id))); ?>

          <?php $__empty_1 = true; foreach($survey->questions as $key=>$question): $__empty_1 = false; ?>
            <p class="flow-text">Question <?php echo e($key+1); ?> - <?php echo e($question->title); ?> </p>
                <?php if($question->question_type === 'text'): ?>
                  <div class="input-field col s12">
                    <input id="answer" type="text" name="<?php echo e($question->id); ?>[answer]" class='required'>
                    <label for="answer">Answer</label>
                  </div>
                  <div class="errorTxt"></div>
                <?php elseif($question->question_type === 'textarea'): ?>
                  <div class="input-field col s12">
                    <textarea id="textarea1" class="materialize-textarea required" name="<?php echo e($question->id); ?>[answer]"></textarea>
                    <label for="answer">Answer</label>
                  </div>
                  <div class="errorTxt"></div>
                <?php elseif($question->question_type === 'radio'): ?>
                  <?php foreach($question->option_name as $key=>$value): ?>
                    <div style="margin:0px; padding:0px;" data-error="Error msg here">
                      <input name="<?php echo e($question->id); ?>[answer]" type="radio" id="<?php echo e($key); ?>" class="required" />
                      <label for="<?php echo e($key); ?>"><?php echo e($value); ?></label>
                    </div>
                  <?php endforeach; ?>
                  <div class="errorTxt"></div>
                <?php elseif($question->question_type === 'select'): ?>
                  <p style="margin:0px; padding:0px;">
                    <select name="<?php echo e($question->id); ?>[answer]" class="required">
                      <?php foreach($question->option_name as $value): ?>
                        <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                      <?php endforeach; ?>
                    </select>
                  </p>
                  <div class="errorTxt"></div>
                <?php elseif($question->question_type === 'checkbox'): ?>
                  <?php foreach($question->option_name as $key=>$value): ?>
                  <p style="margin:0px; padding:0px;">
                    <input type="checkbox"  id="something<?php echo e($key); ?>" name="<?php echo e($question->id); ?>[answer]" />
                    <label for="something<?php echo e($key); ?>"><?php echo e($value); ?></label>
                  </p>
                  <?php endforeach; ?>
                  <div class="errorTxt"></div>
                <?php endif; ?> 
              <div class="divider" style="margin:10px 10px;"></div>
          <?php endforeach; if ($__empty_1): ?>
            <span class='flow-text center-align'>Nothing to show</span>
          <?php endif; ?>
        <?php echo e(Form::submit('Submit Survey', array('class'=>'btn waves-effect waves-light'))); ?>

        <?php echo Form::close(); ?>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>

  <script type="text/javascript">
    $('document').ready(function() {
      $('form').validate({
        errorElement : 'div',
        errorPlacement: function(error, element) {
          $(".errorTxt").text($(error).text());
        }
      });
    })
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>